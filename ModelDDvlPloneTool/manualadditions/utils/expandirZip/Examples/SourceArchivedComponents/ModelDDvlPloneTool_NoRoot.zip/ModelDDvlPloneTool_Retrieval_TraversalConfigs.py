# -*- coding: utf-8 -*-
#
# File: ModelDDvlPloneTool_Retrieval_TraversalConfigs.py
#
# Copyright (c) 2008 by 2008 Model Driven Development sl and Antonio Carrasco Valero
#
#
# GNU General Public License (GPL)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#
#
# Authors: 
# Model Driven Development sl  Valencia (Spain) www.ModelDD.org 
# Antonio Carrasco Valero                       carrasco@ModelDD.org
#

__author__ = """Model Driven Development sl <gvSIGwhys@ModelDD.org>,
Antonio Carrasco Valero <carrasco@ModelDD.org>"""
__docformat__ = 'plaintext'



from AccessControl      import ClassSecurityInfo
from Acquisition        import aq_inner, aq_parent


from ModelDDvlPloneTool_Visitor                            import ModelDDvlPloneTool_Visitor

   

class ModelDDvlPloneTool_Retrieval_TraversalConfigs:
    """
    """
    security = ClassSecurityInfo()


   
 
 

    
# ##################################################################
# Accessor for the traversal configuration to drive Generic rendering 
#
        

    
    security.declarePublic( 'getAllTypeConfigs')
    def getAllTypeConfigs(self, theContextElement):
        if not theContextElement:
            return []
                           
        allTypeConfigs = self.getTraversalConfig( theContextElement)
        if not allTypeConfigs:
            return []
         
        someScannedTypeConfigs = self.preScanTypeConfigsStandAlone( allTypeConfigs)   
        return someScannedTypeConfigs
        

       
       
        
    security.declarePrivate( 'getTypeConfig')
    def getTypeConfig(self, theContextElement, theTypeName, theAllTypeConfigs=None, theConfigName=""):   
        
        anAllTypeConfigs = theAllTypeConfigs
        if not anAllTypeConfigs:
            if not theNombreProyecto:
                return []
            anAllTypeConfigs = self.getAllTypeConfigs( theContextElement)
            
        if not anAllTypeConfigs:
            return None

        
        if not anAllTypeConfigs.has_key( theTypeName):
            return None
        
        aTypeConfig = None

        someConfigsForType =  anAllTypeConfigs[ theTypeName]
        if someConfigsForType:
            if theConfigName:        
                if someConfigsForType.has_key( theConfigName):           
                    aTypeConfig = someConfigsForType[ theConfigName]
                
            if not aTypeConfig:
                if someConfigsForType.has_key( 'Default'):    
                    aTypeConfig = someConfigsForType[ 'Default']
                else:
                    aTypeConfig =  someConfigsForType[ 0]
        return aTypeConfig

   
 
  
  
  
  
 

   
# ##################################################################
# Accessor for the traversal configuration to find elements impacted by deletion of an element
#
        
 
    security.declarePrivate( 'getRelatedDependentScanTypeConfigs')
    def getRelatedDependentScanTypeConfigs(self, theNombreProyecto):               
        return self.getAllTypeConfigs( theNombreProyecto)
  
       
             

             
###########################
#  Traversal config accessors
###########################            
          


           

      
    security.declarePrivate('getTraversalConfig')
    def getTraversalConfig(self, theContextElement):
        
        if not theContextElement:
            return []

        unNombreProyecto = ''
        try:
            unNombreProyecto = theContextElement.getNombreProyecto()   
        except:
            None            
        if not unNombreProyecto:
            return None

        unEditableConfigScriptName = self.traversalConfigScriptName( unNombreProyecto)
        if unEditableConfigScriptName:
            unaConfig = self.traversalConfig_FromScript( theContextElement, unEditableConfigScriptName)
            if unaConfig:
                return unaConfig

        unaConfig = None
        try:
            unaConfig = theContextElement.traversalConfig()
        except:
            None
        return unaConfig
           



   



    security.declarePrivate('traversalConfigScriptName')
    def traversalConfigScriptName(self, theNombreProyecto):
        
        if not theNombreProyecto:
            return []
            
        unTraversalConfigScriptName =  "%s_TraversalConfig_Script" % theNombreProyecto
        return unTraversalConfigScriptName






    security.declarePrivate('TraversalConfig_FromScript')
    def traversalConfig_FromScript( self, theContextElement, theTraversalConfigName):
        if not theContextElement:
            return []

        if not theTraversalConfigName:
            return None        

        aScript   = None
        try:
            aScript = theContextElement.unrestrictedTraverse( theTraversalConfigName)
        except:
            None
            
        if not aScript:
            return None

        aContext          = aq_inner( theContextElement)  
        if not aContext:
            return None
                     
        aScriptInContext  = aScript.__of__( aContext)
        if not aScriptInContext:
            return None
        
        anTraversalConfig = aScriptInContext()       
        if anTraversalConfig is None or len( anTraversalConfig) < 1:
            return None 
                   
        return anTraversalConfig

    

          


   
   
# #########################
# Traversal config scanning and resolution methods
#

 

          
    security.declarePrivate( 'preScanTypeConfigsStandAlone')
    def preScanTypeConfigsStandAlone( self, theItemsConfig):
        if  theItemsConfig is None:
            return {}
    
        someFoundTypeConfigsDict = {}
        self.preScanTypeConfigsStandAloneRecursive( theItemsConfig, someFoundTypeConfigsDict)
        return someFoundTypeConfigsDict
        
        
        
        
           
    security.declarePrivate( 'preScanTypeConfigsStandAloneRecursive')
    def preScanTypeConfigsStandAloneRecursive( self,theItemsConfig, theFoundTypeConfigsDict):
        if  theItemsConfig is None or  theFoundTypeConfigsDict is None:
            return { }
    
        for aTypeConfig in theItemsConfig:
            if not aTypeConfig.has_key( 'reuse_config'):  
                
                unConfigName = 'Default'
                if aTypeConfig.has_key( 'config_name'):
                    unConfigName = aTypeConfig[ 'config_name']
                    
                somePortalTypes = aTypeConfig[ 'portal_types'] 
                for aTypeName in somePortalTypes:
                    if not theFoundTypeConfigsDict.has_key( aTypeName):
                        someTypeConfigs = { }
                        theFoundTypeConfigsDict[ aTypeName] = someTypeConfigs
                    else:
                        someTypeConfigs = theFoundTypeConfigsDict[ aTypeName]   
                    
                    if not someTypeConfigs.has_key( unConfigName):
                        someTypeConfigs[ unConfigName] = aTypeConfig                                        
    
                if aTypeConfig.has_key( 'traversals'):
                    someTraversalConfigs = aTypeConfig[ 'traversals']
                    for aTraversalConfig in someTraversalConfigs:
                        if aTraversalConfig.has_key( 'subitems'):
                            someSubitemsTypesConfigs = aTraversalConfig[ 'subitems']
                            self.preScanTypeConfigsStandAloneRecursive( someSubitemsTypesConfigs, theFoundTypeConfigsDict)                        
    
                        elif aTraversalConfig.has_key( 'related_types'):
                            someRelatedTypesConfigs = aTraversalConfig[ 'related_types']
                            self.preScanTypeConfigsStandAloneRecursive( someRelatedTypesConfigs, theFoundTypeConfigsDict)
        
        return theFoundTypeConfigsDict
    

        
        
        
 