#! /bin/bash

source ./set_paths.sh

soustring=`date +%Y%m%d%H%M`
export soustring


rm -r "${MDDwork_path}/ModelDDvlPlone-dvpt"

mkdir  "${MDDwork_path}/ModelDDvlPlone-dvpt"
mkdir  "${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPlone"
mkdir  "${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPloneConfiguration"
mkdir  "${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPloneTool"
mkdir  "${MDDwork_path}/ModelDDvlPlone-dvpt/scripts"
mkdir  "${MDDwork_path}/ModelDDvlPlone-dvpt/bats"

rsync  -r --exclude=.svn  ${MDDsources_path}/ModelDDvlPlone/additions           ${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPlone
rsync  -r --exclude=.svn  ${MDDsources_path}/ModelDDvlPlone/manualadditions     ${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPlone

rsync  -r --exclude=.svn  ${MDDsources_path}/ModelDDvlPloneConfiguration/additions  ${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPloneConfiguration

rsync  -r --exclude=.svn  ${MDDsources_path}/ModelDDvlPloneTool/additions           ${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPloneTool
rsync  -r --exclude=.svn  ${MDDsources_path}/ModelDDvlPloneTool/manualadditions     ${MDDwork_path}/ModelDDvlPlone-dvpt/ModelDDvlPloneTool


cp ./*.sh    "${MDDwork_path}/ModelDDvlPlone-dvpt/scripts"
cp ${MDDbase_path}/generation/*.bat    "${MDDwork_path}/ModelDDvlPlone-dvpt/bats"

cp "${MDDthirdparty_path}/Relations_06bMDDsl02.zip" "${MDDwork_path}/ModelDDvlPlone-dvpt"
cp "${MDDthirdparty_path}/simplejson-2.0.9.tar.gz" "${MDDwork_path}/ModelDDvlPlone-dvpt"

rm "${MDDwork_path}/ModelDDvlPlone-dvpt.zip"
rm "${MDDwork_path}/ModelDDvlPlone-dvpt-${soustring}.zip"

pushd "${MDDwork_path}" > /dev/null
zip -r -q ModelDDvlPlone-dvpt.zip ModelDDvlPlone-dvpt
cp ModelDDvlPlone-dvpt.zip "ModelDDvlPlone-dvpt-${soustring}.zip"
cp ModelDDvlPlone-dvpt.zip $MDDbase_path/generation
popd > /dev/null