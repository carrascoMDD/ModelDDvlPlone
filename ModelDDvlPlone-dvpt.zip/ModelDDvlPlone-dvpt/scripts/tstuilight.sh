#! /bin/bash

./build_tstui.sh
./deplight_tstui.sh
TIME /T