#! /bin/bash

attrib -R /S ./ModelDDvlPloneTestUI_dep_sec/*.*
del /Q /S ./ModelDDvlPloneTestUI_dep_sec/*.*
rmdir /Q /S ./ModelDDvlPloneTestUI_dep_sec
cp "D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestUI" ./ModelDDvlPloneTestUI_dep_sec    
attrib -R /S D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestUI/*.*
del /S /Q D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestUI/*.*
rmdir /Q /S D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestUI
./deplight_tstui.sh
