#! /bin/bash

./build_tsttool.sh
./dep_tsttool.sh
TIME /T