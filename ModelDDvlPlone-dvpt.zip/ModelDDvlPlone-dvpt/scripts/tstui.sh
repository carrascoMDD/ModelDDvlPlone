#! /bin/bash

./build_tstui.sh
./dep_tstui.sh
TIME /T