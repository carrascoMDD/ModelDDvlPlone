#! /bin/bash

source ./set_paths.sh

echo 
echo "deliver.sh"
echo

buildstring=`date +%Y%m%d%H%M`
export buildstring


rm -r  "${MDDdeliverwork_path}/ModelDDvlPlone"
mkdir "${MDDdeliverwork_path}/ModelDDvlPlone"
mkdir "${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products"
mkdir "${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Extensions"


rsync  -r --exclude=.svn  --exclude="*.bak" $MDDbase_path/generation/ModelDDvlPlone              ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products
rsync  -r --exclude=.svn  --exclude="*.bak" $MDDbase_path/generation/ModelDDvlPloneTool          ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products
rsync  -r --exclude=.svn  --exclude="*.bak" $MDDbase_path/generation/ModelDDvlPloneConfiguration ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products

rsync  -r --exclude=.svn  --exclude="*.bak"  $MDDbase_path/generation/ModelDDvlPlone/manualadditions/AsExternalMethodInSiteRoot/       ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Extensions
rsync  -r --exclude=.svn  --exclude="*.bak"  $MDDbase_path/generation/ModelDDvlPloneTool/manualadditions/AsExternalMethodInSiteRoot/       ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Extensions

rsync  -r --exclude=.svn  --exclude="*.bak" $MDDbase_path/ThirdParty/Relations          ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products

cp $MDDbase_path/generation/ModelDDvlPlone-dvpt.zip          ${MDDdeliverwork_path}/ModelDDvlPlone

cp ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPlone/version_base.txt ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPlone/version.txt
printf "b%s" $buildstring >>"${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPlone/version.txt"

cp ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPloneTool/version_base.txt ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPloneTool/version.txt
printf "b%s" $buildstring >>"${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPloneTool/version.txt"

cp ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPloneConfiguration/version_base.txt ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPloneConfiguration/version.txt
printf "b%s" $buildstring >>"${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPloneConfiguration/version.txt"

MDDversion=`cat ${MDDdeliverwork_path}/ModelDDvlPlone/To_Plone_instance_Products/ModelDDvlPlone/version.txt`
export MDDversion


mv ${MDDdeliverwork_path}/ModelDDvlPlone ${MDDdeliverwork_path}/ModelDDvlPlone-${MDDversion}


pushd ${MDDdeliverwork_path} > /dev/null
rm ModelDDvlPlone-${MDDversion}.zip 
zip -r -q ModelDDvlPlone-${MDDversion}.zip ModelDDvlPlone-${MDDversion}
cp ModelDDvlPlone-${MDDversion}.zip $MDDbase_path/delivery

rm ModelDDvlPlone-${MDDversion}.tar
tar -cvf ModelDDvlPlone-${MDDversion}.tar ModelDDvlPlone-${MDDversion}
gzip ModelDDvlPlone-${MDDversion}.tar
cp ModelDDvlPlone-${MDDversion}.tar.gz $MDDbase_path/delivery

popd > /dev/null
