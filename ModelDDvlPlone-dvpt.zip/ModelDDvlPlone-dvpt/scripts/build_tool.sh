#! /bin/bash

source ./set_paths.sh

buildstring=`date +%Y%m%d%H%M`
export buildstring



rm -r  "${MDDwork_path}/ModelDDvlPloneTool"

mkdir "${MDDwork_path}/ModelDDvlPloneTool"
mkdir "${MDDwork_path}/ModelDDvlPloneTool/skins"
mkdir "${MDDwork_path}/ModelDDvlPloneTool/manualadditions"
mkdir "${MDDwork_path}/ModelDDvlPloneTool/manualadditions/AsExternalMethodInSiteRoot"

rsync  -r --exclude=.svn --exclude="*.bak" ${MDDsources_path}/ModelDDvlPloneTool/additions/objects/           ${MDDwork_path}/ModelDDvlPloneTool
rsync  -r --exclude=.svn --exclude="*.bak" ${MDDsources_path}/ModelDDvlPloneTool/additions/skins/             ${MDDwork_path}/ModelDDvlPloneTool/skins
rsync  -r --exclude=.svn --exclude="*.bak" ${MDDsources_path}/ModelDDvlPloneTool/manualadditions/AsExternalMethodInSiteRoot/       ${MDDwork_path}/ModelDDvlPloneTool/manualadditions/AsExternalMethodInSiteRoot

cp "${MDDwork_path}/ModelDDvlPloneTool/version_base.txt" "${MDDwork_path}/ModelDDvlPloneTool/version.txt"
printf "build%s" $buildstring >>"${MDDwork_path}/ModelDDvlPloneTool/version.txt"


rm "${MDDwork_path}/ModelDDvlPloneTool.zip"
rm "${MDDwork_path}/ModelDDvlPloneTool-${buildstring}.zip"

pushd ${MDDwork_path} > /dev/null
zip -r -q ModelDDvlPloneTool.zip ModelDDvlPloneTool
cp ModelDDvlPloneTool.zip "ModelDDvlPloneTool-${buildstring}.zip"
cp ModelDDvlPloneTool.zip $MDDbase_path/generation
popd > /dev/null

mkdir $MDDbase_path/generation/ModelDDvlPloneTool
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDwork_path}/ModelDDvlPloneTool/  $MDDbase_path/generation/ModelDDvlPloneTool

./sou.sh

