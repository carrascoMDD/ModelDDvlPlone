#! /bin/bash

./productlight.sh
./toollight.sh
./configlight.sh
TIME /T