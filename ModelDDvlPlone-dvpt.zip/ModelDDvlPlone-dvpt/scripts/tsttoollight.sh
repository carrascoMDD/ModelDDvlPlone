#! /bin/bash

./build_tsttool.sh
./deplight_tsttool.sh
TIME /T