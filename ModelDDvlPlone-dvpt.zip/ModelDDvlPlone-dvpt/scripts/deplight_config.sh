#! /bin/bash

source ./set_paths.sh

chmod -R o+r ${MDDwork_path}/ModelDDvlPloneConfiguration/*
sudo -u zopei18n  cp -r ${MDDwork_path}/ModelDDvlPloneConfiguration  "${MDDzopeinstance_path}/Products/ModelDDvlPloneConfiguration"   

