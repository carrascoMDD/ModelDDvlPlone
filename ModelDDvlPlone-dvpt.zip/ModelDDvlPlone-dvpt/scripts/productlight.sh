#! /bin/bash

source ./build_product.sh
source ./deplight_product.sh
date