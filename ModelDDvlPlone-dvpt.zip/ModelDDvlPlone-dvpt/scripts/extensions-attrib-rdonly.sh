#! /bin/bash

attrib D:/dvpt/plone251/Data/Extensions/MDD*.py +R /S