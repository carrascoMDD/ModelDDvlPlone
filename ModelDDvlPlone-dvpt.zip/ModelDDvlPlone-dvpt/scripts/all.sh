#! /bin/bash

# for f in *.bat; do mv $f `basename $f .bat`.sh; done;

./product.sh
./tool.sh
./config.sh
date