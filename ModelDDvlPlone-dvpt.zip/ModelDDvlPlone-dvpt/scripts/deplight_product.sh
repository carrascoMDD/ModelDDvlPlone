#! /bin/bash

source ./set_paths.sh

chmod -R o+r ${MDDwork_path}/ModelDDvlPlone/*
sudo -u zopei18n  cp -r ${MDDwork_path}/ModelDDvlPlone  "${MDDzopeinstance_path}/Products/ModelDDvlPlone"   
sudo -u zopei18n  cp ${MDDwork_path}/ModelDDvlPlone/manualadditions/AsExternalMethodInSiteRoot/MDD*.py  "${MDDzopeinstance_path}/Extensions"    

