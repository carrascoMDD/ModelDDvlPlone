#! /bin/bash

attrib D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestUI/*.* -R /S
cp ./ModelDDvlPloneTestUI  "D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestUI"   
attrib D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestUI/*.* +R /S
./extensions-attrib.sh
cp ./ModelDDvlPloneTestUI/manualadditions/AsExternalMethodInSiteRoot/MDD*.py  "D:/dvpt/plone251/Data/Extensions"    
./extensions-attrib-rdonly.sh



