#! /bin/bash

echo {%%1} >cmdlog.txt