#! /bin/bash

source ./build_tool.sh
source ./deplight_tool.sh
date