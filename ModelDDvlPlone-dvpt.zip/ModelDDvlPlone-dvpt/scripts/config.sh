#! /bin/bash

source ./build_config.sh
source ./dep_config.sh
date