#! /bin/bash

TIME /T
REM ******************
REM ModelDDvlPlone
REM ******************
attrib -R /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPlone/*.*
del /S /Q //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPlone/*.*
rmdir /Q /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPlone
cp ./ModelDDvlPlone  //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPlone   
attrib +R /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPlone/*.* 
REM ******************
REM ModelDDvlPloneTool
REM ******************
attrib -R /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneTool/*.*
del /S /Q //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneTool/*.*
rmdir /Q /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneTool
cp ./ModelDDvlPloneTool  //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneTool   
attrib +R /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneTool/*.* 
REM ******************
REM ModelDDvlPloneConfiguration
REM ******************
attrib -R /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneConfiguration/*.*
del /S /Q //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneConfiguration/*.*
rmdir /Q /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneConfiguration
cp ./ModelDDvlPloneConfiguration  //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneConfiguration   
attrib +R /S //ACVP06/dvpt/Plone251/Data/Products/ModelDDvlPloneConfiguration/*.* 
REM ******************
REM Extensions from ModelDDvlPlone, ModelDDvlPloneTool
REM ******************
attrib -R /S //ACVP06/dvpt/Plone251/Data/Extensions/*.*
cp ./ModelDDvlPlone/manualadditions/AsExternalMethodInSiteRoot/*.*  //ACVP06/dvpt/Plone251/Data/Extensions   
cp ./ModelDDvlPloneTool/manualadditions/AsExternalMethodInSiteRoot/*.*  //ACVP06/dvpt/Plone251/Data/Extensions   
attrib +R /S //ACVP06/dvpt/Plone251/Data/Extensions/*.*
TIME /T
