#! /bin/bash


attrib ./dvpt -R /S

rmdir /S /Q ./dvpt

mkdir ./dvpt
mkdir ./dvpt/ModelDDvlPloneTestTool
mkdir ./dvpt/ModelDDvlPloneTestUI
mkdir ./dvpt/scripts

cp ../../sources/ModelDDvlPloneTestTool/additions/*.*               ./dvpt/ModelDDvlPloneTestTool/additions/   
cp ../../sources/ModelDDvlPloneTestTool/manualadditions/*.*         ./dvpt/ModelDDvlPloneTestTool/manualadditions/   


cp ../../sources/ModelDDvlPloneTestUI/additions/*.*               ./dvpt/ModelDDvlPloneTestUI/additions/   
cp ../../sources/ModelDDvlPloneTestUI/manualadditions/*.*         ./dvpt/ModelDDvlPloneTestUI/manualadditions/   


cp ./*.sh   ./dvpt/scripts   



attrib ./ModelDDvlPloneTestTool/ModelDDvlPloneTestTool-dvpt.zip -R

del /Q ./ModelDDvlPloneTestTool/ModelDDvlPloneTestTool-dvpt.zip

"C:/Program Files/7-Zip/7z" a -r -y  ./ModelDDvlPloneTestTool/ModelDDvlPloneTestTool-dvpt.zip ./dvpt

attrib ./ModelDDvlPloneTestTool/ModelDDvlPloneTestTool-dvpt.zip +R


REM leave to review. Shall be deleted at the beginning of the next execution of this script rmdir /S /Q ./dvpt