#! /bin/bash

source ./set_paths.sh


rm -r ${MDDwork_path}/ModelDDvlPloneTool_dep_sec
sudo cp -r "${MDDzopeinstance_path}/Products/ModelDDvlPloneTool" ${MDDwork_path}/ModelDDvlPloneTool_dep_sec    
sudo chown -R $MDDuserid:$MDDgroupid  ${MDDwork_path}/ModelDDvlPloneTool_dep_sec
sudo rm -r "${MDDzopeinstance_path}/Products/ModelDDvlPloneTool"
source ./deplight_tool.sh
