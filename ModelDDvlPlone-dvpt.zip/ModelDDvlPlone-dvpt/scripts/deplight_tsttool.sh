#! /bin/bash

attrib D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestTool/*.* -R /S
cp ./ModelDDvlPloneTestTool  "D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestTool"   
attrib D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestTool/*.* +R /S
./extensions-attrib.sh
cp ./ModelDDvlPloneTestTool/manualadditions/AsExternalMethodInSiteRoot/MDD*.py  "D:/dvpt/plone251/Data/Extensions"    
./extensions-attrib-rdonly.sh
