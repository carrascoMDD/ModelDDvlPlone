#! /bin/bash

source ./set_paths.sh

chmod -R o+r ${MDDwork_path}/ModelDDvlPloneTool/*
sudo -u zopei18n  cp -r ${MDDwork_path}/ModelDDvlPloneTool  "${MDDzopeinstance_path}/Products/ModelDDvlPloneTool"   
sudo -u zopei18n  cp ${MDDwork_path}/ModelDDvlPloneTool/manualadditions/AsExternalMethodInSiteRoot/MDD*.py  "${MDDzopeinstance_path}/Extensions"    

