#! /bin/bash

tree ModelDDvlPlone /A /F  > ModelDDvlPlone_tree.txt
tree ModelDDvlPloneTool /A /F  > ModelDDvlPloneTool_tree.txt