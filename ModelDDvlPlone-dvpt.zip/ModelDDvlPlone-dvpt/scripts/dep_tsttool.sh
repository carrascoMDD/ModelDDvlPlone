#! /bin/bash

attrib -R /S ./ModelDDvlPloneTestTool_dep_sec/*.*
del /Q /S ./ModelDDvlPloneTestTool_dep_sec/*.*
rmdir /Q /S ./ModelDDvlPloneTestTool_dep_sec
cp "D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestTool" ./ModelDDvlPloneTestTool_dep_sec    
attrib -R /S D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestTool/*.*
del /S /Q D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestTool/*.*
rmdir /Q /S D:/dvpt/plone251/Data/Products/ModelDDvlPloneTestTool
./deplight_tsttool.sh
