#! /bin/bash

source ./set_paths.sh

buildstring=`date +%Y%m%d%H%M`
export buildstring


rm -r  "${MDDwork_path}/ModelDDvlPlone"
mkdir "${MDDwork_path}/ModelDDvlPlone"
mkdir "${MDDwork_path}/ModelDDvlPlone/Extensions"
mkdir "${MDDwork_path}/ModelDDvlPlone/i18n"
mkdir "${MDDwork_path}/ModelDDvlPlone/skins"
mkdir "${MDDwork_path}/ModelDDvlPlone/skins/ModelDDvlPlone"
mkdir "${MDDwork_path}/ModelDDvlPlone/manualadditions"
mkdir "${MDDwork_path}/ModelDDvlPlone/manualadditions/AsExternalMethodInSiteRoot"

rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/objects/           ${MDDwork_path}/ModelDDvlPlone
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/Extensions/        ${MDDwork_path}/ModelDDvlPlone/Extensions
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/i18n/              ${MDDwork_path}/ModelDDvlPlone/i18n
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/skins/scripts/     ${MDDwork_path}/ModelDDvlPlone/skins/ModelDDvlPlone
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/skins/vistas/      ${MDDwork_path}/ModelDDvlPlone/skins/ModelDDvlPlone
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/skins/grids_i18n/  ${MDDwork_path}/ModelDDvlPlone/skins/ModelDDvlPlone
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/skins/bodies_i18n/ ${MDDwork_path}/ModelDDvlPlone/skins/ModelDDvlPlone
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/additions/skins/icons/       ${MDDwork_path}/ModelDDvlPlone/skins/ModelDDvlPlone
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDsources_path}/ModelDDvlPlone/manualadditions/AsExternalMethodInSiteRoot/       ${MDDwork_path}/ModelDDvlPlone/manualadditions/AsExternalMethodInSiteRoot

cp "${MDDwork_path}/ModelDDvlPlone/version_base.txt" "${MDDwork_path}/ModelDDvlPlone/version.txt"
printf "build%s" $buildstring >>"${MDDwork_path}/ModelDDvlPlone/version.txt"

rm "${MDDwork_path}/ModelDDvlPlone.zip"
rm "${MDDwork_path}/ModelDDvlPlone-${buildstring}.zip"

pushd ${MDDwork_path} > /dev/null
zip -r -q ModelDDvlPlone.zip ModelDDvlPlone
cp ModelDDvlPlone.zip "ModelDDvlPlone-${buildstring}.zip"
cp ModelDDvlPlone.zip $MDDbase_path/generation
popd > /dev/null

mkdir $MDDbase_path/generation/ModelDDvlPlone
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDwork_path}/ModelDDvlPlone/  $MDDbase_path/generation/ModelDDvlPlone

./sou.sh

