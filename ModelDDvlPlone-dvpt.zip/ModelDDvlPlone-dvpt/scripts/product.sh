#! /bin/bash

source ./build_product.sh
source ./dep_product.sh
date
