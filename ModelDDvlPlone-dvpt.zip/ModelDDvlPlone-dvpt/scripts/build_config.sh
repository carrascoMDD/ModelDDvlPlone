#! /bin/bash

source ./set_paths.sh

buildstring=`date +%Y%m%d%H%M`
export buildstring


rm -r  "${MDDwork_path}/ModelDDvlPloneConfiguration"
mkdir "${MDDwork_path}/ModelDDvlPloneConfiguration"
mkdir "${MDDwork_path}/ModelDDvlPloneConfiguration/skins"

rsync  -r --exclude=.svn --exclude="*.bak" ${MDDsources_path}/ModelDDvlPloneConfiguration/additions/objects/           ${MDDwork_path}/ModelDDvlPloneConfiguration
rsync  -r --exclude=.svn --exclude="*.bak" ${MDDsources_path}/ModelDDvlPloneConfiguration/additions/skins/             ${MDDwork_path}/ModelDDvlPloneConfiguration/skins

cp "${MDDwork_path}/ModelDDvlPloneConfiguration/version_base.txt" "${MDDwork_path}/ModelDDvlPloneConfiguration/version.txt"
printf "build%s" $buildstring >>"${MDDwork_path}/ModelDDvlPloneConfiguration/version.txt"

rm "${MDDwork_path}/ModelDDvlPloneConfiguration.zip"
rm "${MDDwork_path}/ModelDDvlPloneConfiguration-${buildstring}.zip"

pushd ${MDDwork_path} > /dev/null
zip -r -q ModelDDvlPloneConfiguration.zip ModelDDvlPloneConfiguration
cp ModelDDvlPloneConfiguration.zip "ModelDDvlPloneConfiguration-${buildstring}.zip"
cp ModelDDvlPloneConfiguration.zip $MDDbase_path/generation
popd > /dev/null

mkdir $MDDbase_path/generation/ModelDDvlPloneConfiguration
rsync  -r --exclude=.svn  --exclude="*.bak" ${MDDwork_path}/ModelDDvlPloneConfiguration/  $MDDbase_path/generation/ModelDDvlPloneConfiguration

./sou.sh

