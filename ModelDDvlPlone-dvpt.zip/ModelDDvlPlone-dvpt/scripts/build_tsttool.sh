#! /bin/bash

set buildstring=build%DATE:~6,4%%DATE:~3,2%%DATE:~0,2%%TIME:~0,2%%TIME:~3,2%
REM set buildstring=build%DATE:~0,4%%DATE:~5,2%%DATE:~8,2%%TIME:~0,2%%TIME:~3,2%
copy ../../sources/ModelDDvlPloneTestTool/additions/objects/version_base.txt ../../sources/ModelDDvlPloneTestTool/additions/objects/version.txt
echo %buildstring% >>../../sources/ModelDDvlPloneTestTool/additions/objects/version.txt
attrib ./ModelDDvlPloneTestTool/*.* -R /S
del /Q /S ./ModelDDvlPloneTestTool/*.*
rmdir /Q /S ./ModelDDvlPloneTestTool
cp ../../sources/ModelDDvlPloneTestTool/additions/objects/*.*              ./ModelDDvlPloneTestTool   
cp ../../sources/ModelDDvlPloneTestTool/additions/skins/*.*                ./ModelDDvlPloneTestTool/skins   
cp ../../sources/ModelDDvlPloneTestTool/manualadditions/*.*                ./ModelDDvlPloneTestTool/manualadditions   

del /S /Q ./ModelDDvlPloneTestTool/*.bak
attrib ./ModelDDvlPloneTestTool/*.* +R /S


attrib ./ModelDDvlPloneTestTool.zip -R

del /Q ./ModelDDvlPloneTestTool.zip

"C:/Program Files/7-Zip/7z" a -r -y  ./ModelDDvlPloneTestTool.zip ./ModelDDvlPloneTestTool

attrib ./ModelDDvlPloneTestTool.zip +R


