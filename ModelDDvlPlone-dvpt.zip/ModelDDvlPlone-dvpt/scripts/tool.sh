#! /bin/bash

source ./build_tool.sh
source ./dep_tool.sh
date