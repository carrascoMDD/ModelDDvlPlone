#! /bin/bash

# file: depprod_ModelDDvlPlone.sh

# ###################
# Scripted deployment
# for ModelDDvlPlone
# run as user under which the zope instance is executed, or as superuser

ZopeInstancePath="/var/lib/zope2.9/instance/zgvsigi18n"
export ZopeInstancePath

DeliveriesPath="/home/zopei18n/Deliveries"
export DeliveriesPath

ExtractPath="/home/zopei18n/Extract"
export ExtractPath

ModelDDvlPloneName="ModelDDvlPlone-2.1.6b201305010309"
export ModelDDvlPloneName

mkdir $ExtractPath

cp "${DeliveriesPath}/${ModelDDvlPloneName}.tar.gz" $ExtractPath


pushd $ExtractPath

rm -f "${ModelDDvlPloneName}.tar"
rm -r -f ${ModelDDvlPloneName}

echo
echo "unpack archive"
gunzip "${ModelDDvlPloneName}.tar.gz"

echo
echo "Extract from tar"
tar -xvf "${ModelDDvlPloneName}.tar"

echo
echo "After extract from tar"
ls


# Plone products already installed
echo
echo "#########################"
echo "Products: Before delete current"
echo
ls -l "${ZopeInstancePath}/Products/"


# Remove current products

rm -r -f "${ZopeInstancePath}/Products/Relations"
rm -r -f "${ZopeInstancePath}/Products/ModelDDvlPlone"
rm -r -f "${ZopeInstancePath}/Products/ModelDDvlPloneConfiguration"
rm -r -f "${ZopeInstancePath}/Products/ModelDDvlPloneTool"

# Plone products after removal
echo
echo "#########################"
echo "Products: After delete current"
echo
ls -l "${ZopeInstancePath}/Products/"

# Install new releases of products
cp -r "${ExtractPath}/${ModelDDvlPloneName}/To_Plone_instance_Products/Relations" "${ZopeInstancePath}/Products"

cp -r "${ExtractPath}/${ModelDDvlPloneName}/To_Plone_instance_Products/ModelDDvlPlone" "${ZopeInstancePath}/Products"

cp -r "${ExtractPath}/${ModelDDvlPloneName}/To_Plone_instance_Products/ModelDDvlPloneConfiguration" "${ZopeInstancePath}/Products"

cp -r "${ExtractPath}/${ModelDDvlPloneName}/To_Plone_instance_Products/ModelDDvlPloneTool" "${ZopeInstancePath}/Products"

# Plone products after install
echo
echo "#########################"
echo "Products: After install new release"
echo
ls -l "${ZopeInstancePath}/Products/"



# ExternalMethods and other files must be made available to Extensions folder of each instance,


# Files in the external methods directory, before copying
echo
echo "#########################"
echo "Extensions: Before delete current"
echo
ls -l "${ZopeInstancePath}/Extensions"

# Remove current extensions
rm -f ${ZopeInstancePath}/Extensions/MDD*.py

# Files in the external methods directory, after removal
echo
echo "#########################"
echo "Extensions: After delete current"
echo
ls -l ${ZopeInstancePath}/Extensions

# Ext methods from Components for ModelDDvlPlone framework

cp ${ZopeInstancePath}/Products/ModelDDvlPlone/manualadditions/AsExternalMethodInSiteRoot/* ${ZopeInstancePath}/Extensions

cp ${ZopeInstancePath}/Products/ModelDDvlPloneTool/manualadditions/AsExternalMethodInSiteRoot/* ${ZopeInstancePath}/Extensions


# Files in the external methods directory, AFTER copying
echo
echo "#########################"
echo "Extensions: After install new release"
echo
ls -l ${ZopeInstancePath}/Extensions

popd


