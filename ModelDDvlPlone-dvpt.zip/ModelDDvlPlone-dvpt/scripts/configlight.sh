#! /bin/bash

source ./build_config.sh
source ./deplight_config.sh
date